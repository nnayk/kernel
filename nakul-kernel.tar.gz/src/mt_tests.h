/*
 * Nakul Nayak
 * Kernel Project
 * Description:
*/

void simple_test();
void numbers_test();
