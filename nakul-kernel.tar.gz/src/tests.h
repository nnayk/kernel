/*
 * Nakul Nayak
 * Kernel Project
 * Description:
*/

#define assert(condition) ((condition) ? 1 : -1)

void pf_simple_test();
void pf_nonseq_test();
int pf_stress_test();
int kmalloc_tests();
int kbd_tests();
void paging_tests();
int ata_tests();
void vfs_tests();
