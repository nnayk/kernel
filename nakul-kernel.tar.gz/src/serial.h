/*
 * Nakul Nayak
 * Kernel Project
 * Description:
*/
#include "shared_buff.h"
void serial_init();
void serial_consume(int,int,void *);
int serial_write(char, State *);
